#include <stdio.h>

#define MAX_LENGTH 25

typedef struct
{
    char name[MAX_LENGTH + 1];
    double score;
}
student;
